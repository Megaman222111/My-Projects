import java.awt.*;
class Java_Frames {
    public static void main(String[]args){
        Frame f= new Frame("Label Example");
        Label I1, I2;
        I1=new Label("First Label");
        I1.setBounds(50,100,100,30);
        I2=new Label("Second Label");
        I2.setBounds(50,150,100,30);
        f.add(I1);f.add(I2);
        f.setSize(400,400);
        f.setLayout(null);
        f.setVisible(true);
    }
}
