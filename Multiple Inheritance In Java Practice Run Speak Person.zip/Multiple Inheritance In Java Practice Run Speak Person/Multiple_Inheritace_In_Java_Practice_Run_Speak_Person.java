

interface Moveable

{

public void run();

}



interface Speakable

{

public void speak();

}


interface Ability extends Moveable, Speakable

{

public void show();

}

class Person implements Ability

{

@Override

public void run()

{

System.out.println("I can run !!");

}

@Override

public void speak()

{

System.out.println("I can speak !!");

}

@Override

public void show()

{

System.out.println("I am a person, I can speakand run !!");

}

}

public class Multiple_Inheritace_In_Java_Practice_Run_Speak_Person {


public static void main(String[] args)
{

Person obj = new Person();

obj.run();

obj.speak();

obj.show();

}
}
