import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.FlowLayout;
import java.awt.BorderLayout;

public class OnlineStore implements ActionListener{
    
    int a;
    int b,c,d;
    JFrame fr=new JFrame();
    
    JPanel p1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
    JPanel p2=new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JPanel p3=new JPanel(new FlowLayout(FlowLayout.RIGHT));
    JPanel p4=new JPanel(new FlowLayout(FlowLayout.RIGHT));
 
    JButton b1=new JButton("Calculate Grand Total");
    
    JLabel l1=new JLabel("Buy");
    JLabel l2=new JLabel("Return Money");
    JLabel l3=new JLabel("Total Bill");
    JLabel l5=new JLabel("$50");
    JLabel l6=new JLabel("$40");
    JLabel l7=new JLabel("$55");
    JLabel l8=new JLabel("Estimated Total: ");
    JLabel l9=new JLabel("Return Money: ");
    JLabel l10=new JLabel("Grand Total: ");
    
    JCheckBox c1=new JCheckBox("Java Book", false);
    JCheckBox c2=new JCheckBox("C++ Book", false);
    JCheckBox c3=new JCheckBox("Python Book", false);
    
    JTextField t1=new JTextField(15);
    JTextField t2=new JTextField(15);
    JTextField t3=new JTextField(15);
    
    OnlineStore(){
        
        
        p1.setLayout(new BoxLayout(p1,BoxLayout.Y_AXIS));
        p2.setLayout(new BoxLayout(p2,BoxLayout.Y_AXIS));
        
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        p1.setLocation(100,100);
        p2.setLocation(800,100);
        p3.setLocation(100,200);
        
        p1.setSize(300,200);
        l1.setSize(100,100);
        c1.setSize(100,100);
        c2.setSize(100,100);
        c3.setSize(100,100);
        
        t1.setEditable(false);
        t3.setEditable(false);
        
        b1.addActionListener(this);
        p1.add(c1);
        p1.add(l5);
        p1.add(c2);
        p1.add(l6);
        p1.add(c3);
        p1.add(l7);
        p2.add(l8);
        p2.add(t1);
        p2.add(l9);
        p2.add(t2);
        p3.add(b1);
        p4.add(l10);
        p4.add(t3);
        
        p1.setBorder(BorderFactory.createTitledBorder("Buy"));
        fr.add(p1, BorderLayout.NORTH);
        fr.add(p2, BorderLayout.EAST);
        fr.add(p3, BorderLayout.CENTER);
        fr.add(p4, BorderLayout.WEST);
        fr.setTitle("Online Store");
        fr.setSize(610,260);
        fr.setVisible(true);
        
        c1.addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent e)
        {
            if(c1.isSelected()){
                a=a+50;
            }
            
            else{
                a=a-50;
            }
            t1.setText(String.valueOf(a));
        }
        });
        
        c2.addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent e)
        {
            if(c2.isSelected()){
                a=a+40;
            }
            
            else{
                a=a-40;
            }
            t1.setText(String.valueOf(a));
        }
        });
        
        c3.addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent e)
        {
            if(c3.isSelected()){
                a=a+55;
            }
            
            else{
                a=a-55;
            }
            t1.setText(String.valueOf(a));
        }
        });
    }
    
    public void actionPerformed(ActionEvent e)
    {
       
        b=Integer.parseInt(t2.getText());
       c=a-b;
       t3.setText(String.valueOf(c));
    }
    public static void main(String[] args){
        new OnlineStore();
    }
    
}

