
interface Figure

{public final static float PI=3.142F;

 abstract float area(float a, float b);}

class Rectangle implements Figure

{public float area(float m,float n)

{return(m*n);}}

class Triangle implements Figure
{public float area(float x,float y){
return(x * y/2);}}

public class My_First_Interface
{
public static void main(String args[])

{Rectangle r =new Rectangle(); Triangle t=new Triangle();

Figure obj;

obj=r; float f=obj.area(2,4); System.out.println(f);

obj=t; f=obj.area(5,8); System.out.println(f);}}
 
