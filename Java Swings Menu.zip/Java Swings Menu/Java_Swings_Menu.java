import javax.swing.*;

import java.awt.*;

public class Java_Swings_Menu{

public static void main(String args[])

{

JFrame f1=new JFrame();

JButton b1=new JButton("Insert"); JButton b2=new JButton("Update"); JButton b3=new JButton("Delete");

JButton b4=new JButton("View"); JButton b5=new JButton("Previous"); JButton b6=new JButton("Next");

b1.setToolTipText("To Insert New Records");

b2.setToolTipText("To update Records");

b3.setToolTipText("To Delete Existing Records");

b4.setToolTipText("To View Records");

b5.setToolTipText("To see previous Records");

b6.setToolTipText("To see next Records");

JPanel p1=new JPanel();

p1.add(b1);
p1.add(b2);
p1.add(b3);
p1.add(b4);
p1.add(b5);
p1.add(b6);

f1.add(p1);

f1.setSize(500,500);

f1.setVisible(true);

}

}