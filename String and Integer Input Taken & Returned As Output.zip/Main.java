import java.util.Scanner;

public class Main

{ public static void main (String [] args)

{

String str1; int num1;

Scanner in = new Scanner (System.in);

System.out.print ("Type in a line: ");

str1 = in.nextLine ();

System.out.print ("Type in an integer: ");

num1 = in.nextInt ();

System.out.println ("num1:" +num1 +"\t str1:" + str1);

}}