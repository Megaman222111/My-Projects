num=int(input("Enter a number:"))

f=1

if num<0 or num==0:
  print("Either a factorial dosen't exist for this number, or the number you have entered is 0, whose factorial is 0")

else:
  for i in range(1, num+1):
    f=f*i
print("The factorial of this number is:",f)
