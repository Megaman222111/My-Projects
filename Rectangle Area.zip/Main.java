class rectangle

{int l,b;

rectangle(int x,int y)

{l=x;b=y;}

int area()

{return(l*b);}}

public class Main

{public static void main(String args[])

{rectangle r=new rectangle(5,6);

int a=r.area();

System.out.println(a);}} //output=30
