class Vehicle:
  
  def __init__(self, n,m,c):
    self.name=n
    self.milage=m
    self.capacity=c
  

class Bus(Vehicle):
  def __init__(self, n, m, c, cl):
    super().__init__(n,m,c)
    self.colour=cl
    self.fare=c*100
  
  def printstuff(self):
    print("\nName: ", self.name, "\nMilage: ", self.milage, "\nFare: ","$", self.fare,  "\nCapacity: ", self.capacity, "kg", "\nColour: ", self.colour)

a=str(input("Enter the name of the bus: "))
b=str(input("Enter the milage of the bus. Make sure to add a 'km', or a 'miles' at the end of the milage to make sure that it is displayed properly: "))
c=int(input("Please enter the weight capacity of the bus in NUMBERS ONLY. No 'km' or 'miles' at the end: "))
d=str(input("Please enter the colour of the bus "))

x= Bus(a,b,c,d)
x.printstuff()