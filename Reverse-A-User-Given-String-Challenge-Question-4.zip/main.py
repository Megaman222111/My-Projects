def rev(str):
    a = ""
    for ch in str:
        a = ch + a
    return a

b=str(input("Enter A String For It To be Reversed: "))
b=rev(b)
print("Reversed String: ", b)