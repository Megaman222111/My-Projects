#include<iostream>
using namespace std;
int main()
{
    cout<<"Megh";
    return 1;

}