def Test(a, b):
    if a == b or (a-b) == 5 or (a+b) == 5:
        return True
    else:
        return False

n=int(input("Enter your first number: "))
m=int(input("Enter your second number: "))
print(Test(n,m))