indian=["samosa","daal","naan"]
chinese=["egg roll", "pot sticker", "fried rice"]
italian=["pizza", "pasta", "risotto"]

dish=input("Enter a dish name:")

if dish in indian:
  print("Indian")

elif dish in chinese:
  print("Chinese")

elif dish in italian:
  print("Italian")

else:
  print("I don't know what you are taking about")