def histogram(a):
    m= (input("Please Enter The Charater That You Want To Choose: "))
    for n in a:
        output = ''
        b = n
        while( b > 0 ):
          output += m
          b = b - 1
        print(output)

a=int(input("Enter 1st Number For Histogram: "))
b=int(input("Enter 2nd Number For Histogram: "))
c=int(input("Enter 3rd Number For Histogram: "))
d=int(input("Enter 4rth Number For Histogram: "))
histogram([a, b, c, d])