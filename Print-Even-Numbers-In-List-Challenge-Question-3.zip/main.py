numbers = [    
    445, 446, 447, 323, 2234, 234, 1234, 3458 , 2345 , 74243, 235454, 237, 45, 47, 49
    ]

for i in numbers:
    if i == 237:
        print(i)
        break;
    elif i % 2 == 0:
        print(i)
