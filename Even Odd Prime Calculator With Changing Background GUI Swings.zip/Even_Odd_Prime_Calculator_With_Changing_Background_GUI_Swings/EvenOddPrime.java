import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.FlowLayout;
import java.awt.BorderLayout;

class EvenOddPrime implements ActionListener, ItemListener{
    double a;
    double c=0;
    boolean b;
    
    JFrame fr=new JFrame();
    
    JLabel jLabel1=new JLabel("Number");
    JLabel jLabel2=new JLabel("Result");
    JLabel jLabel3=new JLabel("Change your background colour: ");
    
    JTextField t1=new JTextField(20);
    JTextField t2=new JTextField(20);
   
    JButton b1=new JButton("Odd/Even");
    JButton b2=new JButton("Prime");

    JPanel p1=new JPanel(new FlowLayout(FlowLayout.LEFT));
    JPanel p2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
    JPanel p3=new JPanel(new FlowLayout(FlowLayout.LEFT));
    
    JComboBox c1 = new JComboBox();
    
    static boolean isPrime(double n) 
    { 
        if (n <= 1) 
            return false; 
        
        for (double i = 2; i < n; i++) 
            if (n % i == 0) 
                return false; 
  
        return true; 
    } 
    
    EvenOddPrime(){
        
        p1.setLocation(200,200);
        p2.setLocation(400,400);
        p3.setLocation(600,600);
        
        p1.add(jLabel1);
        p1.add(t1);
        t1.setToolTipText("Enter a number");
        
        p2.add(b1);
        p2.add(b2);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b1.setToolTipText("Tells you if the given number is Odd or Even");
        b2.setToolTipText("Tells you if the given number is Prime or Not Prime");
        
        c1.addItem("Default");
        c1.addItem("Red");
        c1.addItem("Green");
        c1.addItem("Blue");
        c1.setToolTipText("Chooses your background colour");
        c1.addItemListener(this);
        
        p3.add(jLabel2);
        p3.add(t2);
        t2.setEditable(false);
        t2.setToolTipText("Displays the answer depending on what number you wrote and what button you chose");
        p3.add(jLabel3);
        p3.add(c1);

        fr.add(p1, BorderLayout.NORTH);
        fr.add(p2, BorderLayout.CENTER);
        fr.add(p3, BorderLayout.SOUTH);
        
        p1.setBackground(Color.white);
        p2.setBackground(Color.white);
        p3.setBackground(Color.white);
        
        fr.setSize(600,200);
        fr.setTitle("Even/Odd/Prime");
        fr.setVisible(true);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        }
    
    public void actionPerformed(ActionEvent e){
        String str = e.getActionCommand();
        a=Integer.parseInt(t1.getText());
        if(str.equals("Odd/Even"))
        {
            if (a%2==0)
            {
                t2.setText("The Number Is Even");
            }
            else
            {
                t2.setText("The Number Is Odd");
            }
        }
        
        else if(str.equals("Prime"))
        {
            if (isPrime(a)){
                t2.setText("The Number Is Prime");
            }
            else{
                t2.setText("The Number Is Composite");
            }
        }
        
    }
    public void itemStateChanged(ItemEvent e){
        String str2=(String)c1.getSelectedItem();
        
        if(str2.equals("Default")){
            p1.setBackground(Color.white);
            p2.setBackground(Color.white);
            p3.setBackground(Color.white);
            jLabel1.setForeground(Color.black);
            jLabel1.setBackground(Color.black);
            jLabel2.setForeground(Color.black); 
            jLabel2.setBackground(Color.black);
            jLabel3.setForeground(Color.black);
            jLabel3.setBackground(Color.black);
        }
        
        else if(str2.equals("Red")){
            p1.setBackground(Color.red);
            p2.setBackground(Color.red);
            p3.setBackground(Color.red);
            jLabel1.setForeground(Color.black);
            jLabel1.setBackground(Color.black);
            jLabel2.setForeground(Color.black); 
            jLabel2.setBackground(Color.black);
            jLabel3.setForeground(Color.black);
            jLabel3.setBackground(Color.black);
        }
        
        else if(str2.equals("Green")){
            p1.setBackground(Color.green);
            p2.setBackground(Color.green);
            p3.setBackground(Color.green);
            jLabel1.setForeground(Color.black);
            jLabel1.setBackground(Color.black);
            jLabel2.setForeground(Color.black); 
            jLabel2.setBackground(Color.black);
            jLabel3.setForeground(Color.black);
            jLabel3.setBackground(Color.black);
        }
        
        else if(str2.equals("Blue")){
            p1.setBackground(Color.blue);
            p2.setBackground(Color.blue);
            p3.setBackground(Color.blue);
            jLabel1.setForeground(Color.white);
            jLabel1.setBackground(Color.white);
            jLabel2.setForeground(Color.white); 
            jLabel2.setBackground(Color.white);
            jLabel3.setForeground(Color.white);
            jLabel3.setBackground(Color.white);
        }
        
    }
    
    public static void main(String args[]){
        new EvenOddPrime();
    }}