class Employee {

String name;

int age;

double salary;

public void printData(){

System.out.println("name: " + name);

System.out.println("age: " + age);

System.out.println("salary: " + salary);

}

}

class Programmer extends Employee {

String language;

public void printData(){

super.printData();

System.out.println("language: " + language);

}

}

class DatabasePro extends Employee {

String databaseTool;

public void printData(){

super.printData();

System.out.println("Database Tool: " + databaseTool);

}

}

public class Main {

public static void main(String[] args){

Employee e = new Employee();

e.name = "Emily";

e.age = 45;

e.salary = 65520.00;

Programmer p = new Programmer();

p.name = "Ben";

p.age = 37;

p.salary = 77435.00;

p.language = "Java";

DatabasePro d = new DatabasePro();

d.name = "Jack";

d.age = 28;

d.salary = 45000.00;

d.databaseTool = "My SQL";

e.printData();

p.printData();

d.printData();

}

}