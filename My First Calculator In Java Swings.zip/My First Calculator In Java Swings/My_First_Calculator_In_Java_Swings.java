import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class My_First_Calculator_In_Java_Swings implements ActionListener{
     JFrame f=new JFrame();
     JLabel jLabel1=new JLabel("FIRST NUMBER");
    JLabel jLabel2=new JLabel("SECOND NUMBER");
    JLabel jLabel3=new JLabel("RESULT");
    
    JTextField jTextField1=new JTextField(20);
    JTextField jTextField2=new JTextField(20);
    JTextField jTextField3=new JTextField(20);
     JButton jButton1=new JButton("Addition");
     JButton jButton2=new JButton("Subtraction");
     JButton jButton3=new JButton("Multiplication");
     JButton jButton4=new JButton("Division");
    
   JPanel p=new JPanel();    
    int a,b,c;

 
My_First_Calculator_In_Java_Swings(){
           jButton1.addActionListener(this);
           jButton2.addActionListener(this);
           jButton3.addActionListener(this);
           jButton4.addActionListener(this);
           
        
          p.add(jLabel1);
           p.add(jTextField1);
           p.add(jLabel2);
           p.add(jTextField2);
           p.add(jButton1);
           p.add(jButton2);
           p.add(jButton3);
           p.add(jButton4);
           
           p.add(jLabel3);
           p.add(jTextField3);    
                    
           f.setSize(400,400);
           f.add(p); 
           f.setVisible(true);
      
    }
public void actionPerformed(ActionEvent ae)
       {
           String str = ae.getActionCommand();	
    System.out.println("You clicked " + str + " button");  

           if(str.equals("Addition"))
           {
               a=Integer.parseInt(jTextField1.getText());
               b=Integer.parseInt(jTextField2.getText());  
               c=a+b;
               jTextField3.setText(String.valueOf(c));
           }
           else if(str.equals("Subtraction"))
            {
               a=Integer.parseInt(jTextField1.getText());
               b=Integer.parseInt(jTextField2.getText());  
               c=a-b;
               jTextField3.setText(String.valueOf(c));
            }
           else if(str.equals("Division"))
            {
               a=Integer.parseInt(jTextField1.getText());
               b=Integer.parseInt(jTextField2.getText());  
               c=a/b;
               jTextField3.setText(String.valueOf(c));
            }
           else if(str.equals("Multiplication"))
            {
               a=Integer.parseInt(jTextField1.getText());
               b=Integer.parseInt(jTextField2.getText());  
               c=a*b;
               jTextField3.setText(String.valueOf(c));
            }
           f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
       }
public static void main(String args[])
      {new My_First_Calculator_In_Java_Swings();}}
