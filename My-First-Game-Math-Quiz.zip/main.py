a=int(input("Enter the number between 1 and 3: "))
b=2
if a==b:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

c=int(input("Enter a number between 5 and 17: "))
e=5
f=17
if c<f and c>e:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

m=int(input("Enter a 12x2: "))
if m==12*2:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
z= random.randint(1,100)
f= random.randint(1,10)
print(z,"x", f)
y=int(input("Multiply these two numbers: "))
if y==z*f:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
t= random.randint(1,10)
k= random.randint(1,10)
print(t,"x", k)
w=int(input("Multiply these two numbers: "))
if w==t*k:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
re= random.randint(1,100)
tr= random.randint(1,1000)
print(re,"," ,tr)
mn=int(input("Write a number between the two numbers listed above: "))
if mn>re and mn<tr:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
rth= random.randint(1,100)
tdr= random.randint(1,1000)
print(rth,"," ,tdr)
ye=int(input("Write a number between the two numbers listed above: "))
if ye>rth and mn<tdr:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
t= random.randint(1,10)
k= random.randint(1,10)
print(t,"x", k)
w=int(input("Multiply these two numbers: "))
if w==t*k:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
t= random.randint(1,10)
k= random.randint(1,10)
print(t,"x", k)
w=int(input("Multiply these two numbers: "))
if w==t*k:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
t= random.randint(1,10)
k= random.randint(1,10)
print(t,"x", k)
w=int(input("Multiply these two numbers: "))
if w==t*k:
  print("Correct!")
else:
  print("Incorrect, please run the program again")
  exit()

import random
t= random.randint(1,10)
k= random.randint(1,10)
print(t,"x", k)
w=int(input("Multiply these two numbers: "))
if w==t*k:
  print("Correct :) Good Job!")
else:
  print("Incorrect, please run the program again")
  exit()