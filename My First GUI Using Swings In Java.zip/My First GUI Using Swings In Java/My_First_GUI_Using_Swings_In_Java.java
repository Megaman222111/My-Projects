import javax.swing.*;

public class My_First_GUI_Using_Swings_In_Java {
    public static void main(String[] args){
        JFrame fr = new JFrame("Test Frame");
        fr.setVisible(true);
    }
}