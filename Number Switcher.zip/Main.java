import java.util.*;
public class Main{
    public static void main(String[] args){
        
        int num, a;
        Scanner in= new Scanner(System.in);
        System.out.println("Enter the number to be reversed: ");
        num=in.nextInt();
        a=num%10;
        num=num/10;
        num=a*10+num;
        System.out.println("The reversed number is: "+num);
    }
}