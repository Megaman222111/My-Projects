import java.util.Scanner;
class Shape
{
    double d1, d2;
    Shape(double a, double b)
    {
        d1=a;
        d2=b;
    }
    public void Area(){
    }
}

class Rectangle extends Shape{
    
    Rectangle(double d1, double d2)
    {
        super(d1,d2);
    }
    public void Area()
    {
        super.Area();
        double a1;
        a1=d1*d2;
        System.out.println("Area: "+a1);
    }
}

class Triangle extends Shape{
    
    Triangle(double d1, double d2)
    {
        super(d1,d2);
    }
    public void Area()
    {
        super.Area();
        double a, a1;
        a=d1*d2;
        a1=a*0.5;
        System.out.println("Area: "+a1);
    }
}

public class Main {
    static boolean stop=false;
    public static void AskToDoAgain()
    {
        
        String newLine = System.getProperty("line.separator");
        Scanner zz=new Scanner(System.in);
        System.out.println("Would you like to do this again?"+newLine+"Write Yes or No: ");
        String s=zz.nextLine();
        
        if(s.equals("Yes")){}
        else if(s.equals("yes")){}
        else if(s.equals("yEs")){}
        else if(s.equals("yeS")){}
        else if(s.equals("YES")){}
        else if(s.equals("YEs")){}
        else if(s.equals("yES")){}
        else if(s.equals("No")){
            stop=true;
        }
        else if(s.equals("no")){
            stop=true;
        }
        else if(s.equals("nO")){
            stop=true;
        }
        else if(s.equals("NO")){
            stop=true;
        }
        else{
            System.out.println("Please Enter Yes or No Instead Of "+s);
            AskToDoAgain();
        }
    }
    
    public static void main(String[] args){
        
        while(stop==false){
            int m, j, h, l, n;
            String newLine = System.getProperty("line.separator");
            Scanner in =new Scanner(System.in);
            System.out.println("Enter 1 if you want to get the area of a rectangle."+newLine+"Enter 2 if you want to get the area of a triangle."+newLine+"Enter your choice: ");
            m=in.nextInt();
            if (m==1){
                Scanner a=new Scanner(System.in);
                System.out.println("Enter the 2 Dimensions of the Square: ");
                j=in.nextInt();
                h=in.nextInt();
                Rectangle e = new Rectangle(j,h);
                e.Area();
                AskToDoAgain();
            }
            else if (m==2){
                Scanner b=new Scanner(System.in);
                System.out.println("Enter the 2 Dimensions of the Triangle: ");
                l=in.nextInt();
                n=in.nextInt();
                Triangle f = new Triangle(l,n);
                f.Area();
                AskToDoAgain();
            }
            else{
                System.out.println("Sorry, "+m+" was not an option");
                AskToDoAgain();
            }
                
        } 
    }
}