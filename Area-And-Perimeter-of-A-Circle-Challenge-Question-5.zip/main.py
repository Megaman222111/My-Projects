class Circle():
    def __init__(a, b):
        a.radius = b

    def area(a):
        return a.radius**2*3.14159265359
    
    def perimeter(a):
        return 2*a.radius*3.14159265359

c=float(input("Give Number To Calculate Area And Perimeter of A Circle: "))
d = Circle(c)
print("Area: ", d.area())
print("Perimeter: ", d.perimeter())