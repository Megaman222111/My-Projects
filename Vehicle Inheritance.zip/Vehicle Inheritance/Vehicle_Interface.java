interface Vehicle {
public void showMaxSpeed();//must be implemented in all classes which implement this
}

class Bus implements Vehicle {
public void showMaxSpeed() { System.out.println("Bus max speed: 100km/h"); } }

class Truck implements Vehicle {
public void showMaxSpeed() {System.out.println("Truck max speed: 80km/h"); }}
public class Vehicle_Interface {

public static void main(String[] args) {
Vehicle bus = new Bus();
Vehicle truck = new Truck();
bus.showMaxSpeed();
truck.showMaxSpeed();
}}