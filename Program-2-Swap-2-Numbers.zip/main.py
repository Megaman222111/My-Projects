a=12323
b=13
c=12

c=b
b=a
a=c

print(a, b)