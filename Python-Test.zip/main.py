n=int(input("Enter the base size of the triangle: "))
m=int(input("Enter the size of the perpendicular side of the triangle: "))

h=n**2
p=m**2
ma=h*p
th= ma**0.5
print(th)