import javax.swing.*;

public class Click_Me_Press_The_Button_With_Text_Box {
    public static void main(String[] args){
        JFrame fr = new JFrame("Test Frame");
        fr.setSize(400,400);
        
        JPanel panel=new JPanel();
        
        JLabel label=new JLabel("Press The Button");
        
        JTextField f=new JTextField(10);
        
        JButton button1= new JButton("Click Me");
        
        panel.add(label);
        panel.add(button1);
        panel.add(f);
        fr.add(panel);
        fr.setVisible(true);
    }
}